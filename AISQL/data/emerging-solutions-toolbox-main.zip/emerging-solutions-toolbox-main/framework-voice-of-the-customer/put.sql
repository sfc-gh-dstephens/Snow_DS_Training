PUT 'file://*.py' @voice_of_the_customer.app.stage_voice_of_the_customer AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
PUT 'file://snow.png' @voice_of_the_customer.app.stage_voice_of_the_customer AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
PUT 'file://environment.yml' @voice_of_the_customer.app.stage_voice_of_the_customer AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
